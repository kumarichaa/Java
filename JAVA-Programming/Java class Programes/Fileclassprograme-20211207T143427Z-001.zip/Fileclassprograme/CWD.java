public class CWD 
{
  public static void main(String[] s) throws Exception {

    String curDir = System.getProperty("user.dir");
System.out.println(curDir);
  }
}